const ele = document.querySelector('.articles');

console.log(ele.classList.add('active'));

console.log(ele.classList.remove('articles'))